  <?php
	include_once("connect.php");
	if( isset($_POST['txtID']) && isset($_POST['txtPassword'])){
		$username = $_POST['txtID'];
		$password = $_POST['txtPassword'];
		$password=md5(md5("jed".$password."ireb"));
		$query = "SELECT id, password FROM tblemployees " . " WHERE id = '$username' AND password = '$password'";
		$result = mysqli_query($con, $query);
		
		if($result->num_rows > 0){
			if(isset($_POST['mobile']) && $_POST['mobile'] == "android"){
				echo "success";
				exit;
			}
			echo "Login Successful";
		} 
		else{
			echo "Login Failed <br/>";
		}
	}
?>
<head>
	<title>Login Form</title>
</head>
<body>
	<h1>Login Example</h1>
		<form action="<?PHP $_PHP_SELF ?>" method="post">
			id <input type="text" name="txtID" value="" /><br/>
			password <input type="password" name="txtPassword" value="" /><br/>
			<input type="submit" name="btnLogin" value="Login"/>
		</form>
</body>

