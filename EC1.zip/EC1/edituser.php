<!DOCTYPE HTML>
<HTML>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Add Employees</title>
	<style type="text/css">
		body {
			background-color:powderblue;
			margin:0;
			}
		a:hover{
			color:#FF0000;
		}
		table{
			border-collapse: collapse;
		}
		th{
			background-color:#7711FF;
		}
		td{
			padding:5px;
		}
		.header_links{
			background-color:Green;
			padding:10px;
			margin:auto;
		}
		.header_links a{
			color:#FFFFFF;
			font-size:18px;
			font-weight:bold;
			
			
		}
		nav ul{
			  list-style: none;
			  margin: 0 2px;
			  padding: 0;
			  display: flex;
			  justify-content: space-around;
			}
			/* Dropdown Button */
		

		/* The container <div> - needed to position the dropdown content */
		.dropdown {
			position: relative;
			display: inline-block;
		}

		/* Dropdown Content (Hidden by Default) */
		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;
		}

		/* Links inside the dropdown */
		.dropdown-content a {
			color: black;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			font-size:14px;
		}

		/* Change color of dropdown links on hover */
		.dropdown-content a:hover {background-color: #f1f1f1}

		/* Show the dropdown menu on hover */
		.dropdown:hover .dropdown-content {
			display: block;
			z-index: 10;
		}

		/* Change the background color of the dropdown button when the dropdown content is shown */
	</style>
</head>
<body>
	<nav class='header_links'>
			<ul>
				<a href="manageemployee.php" class="dropbtn">Employees</a>
				<a href="deleteuser.php" class="dropbtn">User</a>
				<a href='edituser.php' >User Settings</a>
				<a href='logout.php' >Log out</a>
			</ul>
	</nav>
	<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();
	$un=$_SESSION['username'];
	$con=mysqli_connect("localhost","root","","ecnewdeal");
	// Check connection
	if (mysqli_connect_errno())
	{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	$result = mysqli_query($con,"SELECT * FROM tblusers WHERE username='$un'");
		
	echo "<form method=POST><table align=center>";
	while($row = mysqli_fetch_array($result)){
		echo "<tr>
			<td>
				<div class='input-group'>
					<input type='text' class='form-control' placeholder='Username' name='username' value='".$row['username']."' aria-describedby='basic-addon1'>
				</div>
			</td>
		</tr>";
		echo "<tr>
			<td>
				<div class='input-group'>
					<input type='password' class='form-control' placeholder='Password' name='password' value='".$row['password']." aria-describedby='basic-addon1'>
				</div>
			</td>
		</tr>";
	}
	echo "<tr>
			<td>
				<div class='input-group'>
					<input type='password' class='form-control' placeholder='Confirm Password' name='c_password' aria-describedby='basic-addon1'>
				</div>
			</td>
		</tr>";
		
	echo "<tr><td><input type='submit' name='submit' value='EDIT'></td></tr>";
	echo "</table></form>";
		
	$uname=$_POST['username'];
	$pw=$_POST['password'];
	$cpw=$_POST['c_password'];
	if(isset($_POST['submit'])){
		if($pw==$cpw){
			$pw=md5(md5("jed".$pw."ireb"));
			$sql="UPDATE tblusers SET username='$uname',password='$pw' WHERE username='$un'";
			mysqli_query($con,$sql);
			$_SESSION['username']=$uname;
			header('Refrech:0');
		}
	}
	mysqli_close($con);
?>
</body>