<!DOCTYPE HTML>
<html>
	<head>
		<style>
			.Lies{
				margin:auto;
				background-color:#127645;
			}
			
		</style>
		<script>
			function checkAll(source){
				checkboxes = document.getElementsByName('foo');
				  for(var i=0, n=checkboxes.length;i<n;i++) {
					checkboxes[i].checked = source.checked;
				  }
			}
		</script>
	</head>
	<body>
	
		<?php 
			error_reporting(E_ALL ^ E_NOTICE);
			require_once("connect.php");
			$sql=mysqli_query($con,"SELECT * FROM tblemployees");
			echo 
			"<div id='Lies'>
			<input type='text'  name='search'>
			<select>
			  <option value='employee_id'>Employee ID</option>
			  <option value='first_name'>First Name</option>
			  <option value='last_name'>Last Name</option>
			  <option value='employee_type'>Employee Type</option>
			</select>
			<input type='button'  name='search' value='Search'><br>
			<input type='date'  name='start_date'> - <input type='date'  name='end_date'><input type='button'  name='compute' value='Compute'>
			<table border=1>
				<tr>
					<th><input type='checkbox' id='chkAll' onClick='checkAll(this)'>ALL</th>
					<th>Employee ID</th>
					<th>First Name</th>
					<th>Last Name</th>
				</tr>
				";
				
			while($row = mysqli_fetch_array($sql))
			{
				echo "<tr><td><input type='checkbox' id='chk".$row['id']."'name='foo' ></td>";
				echo "<td>". $row['employee_id'] ."</td>";
				echo "<td>". $row['first_name'] ."</td>";
				echo "<td>". $row['last_name'] ."</td>";
				echo "<td>". $row['employee_type'] ."</td>";
				echo "<td><a href='#'>Set Deductions</a>";
				echo "<td><a href='calc.php?id=" . $row['id'] . "'>View Calculation</a>";
				echo "</tr>";
			}
			echo "</table></div>";
			echo "<input type='button'  name='search' value='Set Deductions'>";
			mysqli_close($con);
		?>
	</body>
</html>