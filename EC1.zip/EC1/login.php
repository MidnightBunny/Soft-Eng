<?php
	error_reporting(E_ALL ^ E_NOTICE);
	session_start();

?>
<!DOCTYPE HTML>
<HTML>
<head>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="style.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Log In</title>
</head>
<body>
	<h1 align=center>EC New Deal Supermarket Adminstrator Module</h1>
	


	<?php
	//Creating Form 
	$form = "<form section='./login.php' method='post'>
	<table align=center>
	<th id='box_title' colspan=2>
		User Log In
	</th>
	<tr>
		<td><div class='input-group'>
	<input type='text' class='form-control' placeholder='Username' name='username'aria-describedby='basic-addon1'>
	</div></td>
		
	</tr>
	
	<tr>
		<td><div class='input-group'>
	<input type='password' class='form-control' placeholder='Password' name='password'aria-describedby='basic-addon1'></td>
	</tr>
	<tr>
		<td ><input type='submit' name='loginbtn' value='Login' /></td>
	</tr>
	</table>
	</form>";
	
	
	if ($_POST['loginbtn']){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$_SESSION['username'] = $_POST['username'];
		$warningError = "<div class='alert alert-danger' role='alert'>Invalid Username/Password!</div>";
		$warningPass = "<div class='alert alert-danger' role='alert' >You must enter your password!</div>";
		$warningUser = "<div class='alert alert-danger' role='alert' >You must enter your username!</div>";
		if($username){
			if($password){
				require_once("connect.php");
				if(isset($_POST) && !empty($_POST)){
					$password = md5(md5("jed".$password."ireb"));
					//Check for matching username and password
					$sql = "SELECT * FROM tblusers WHERE username='$username' AND password='$password'";
					$result = mysqli_query($con,$sql);
					$count= mysqli_num_rows($result);
					
					if ($count == 1 ){ //Sucessful log in. Send to Manage employees
						header('Location:manageemployee.php');
					}
					else{
						//Shows Invalid Warning 
						echo "$warningError $form";
					}
					
				}
			}
			else
				//Shows Empty Password Warning
				echo "$warningPass $form";
		}
		else
			//Shows Empty Username Warning
			echo "$warningUser $form";
	}
	else{echo "$form";}
	
	?>
</body>
</HTML>