<?php 
	//Time In/ Time Out
	//Create form
	//
	error_reporting(E_ALL ^ E_NOTICE);
	require_once("connect.php");
	
	$EID=$_POST['employee_id'];
	$password=$_POST['password'];
	$password=md5(md5("jed".$password."ireb"));
	$sql = "SELECT * FROM tblemployees WHERE employee_id='$EID' AND password='$password'";
	$result = mysqli_query($con,$sql);
	$count= mysqli_num_rows($result);
	date_default_timezone_set("Asia/Manila");
		//Time In
		if(isset($_POST['mobile']) && $_POST['mobile'] == "time_in"){
			//validation
			if($count > 0){
				$sqlCheck = "SELECT * FROM tblattendance WHERE employee_id='$EID' AND date='".date("Y-m-d")."'";
				$result = mysqli_query($con,$sqlCheck);
				$sqlCheck2 = "SELECT * FROM tblattendance WHERE employee_id='$EID' AND date='".date("Y-m-d")."' AND timeout1!='00:00:00' AND timein2='00:00:00'";
				$result3 = mysqli_query($con,$sqlCheck2);
				if(mysqli_num_rows($result)==0){
						$sql = "INSERT INTO tblattendance (employee_id,date,timein1) VALUES('$EID','".date("Y-m-d")."','".date("h:i:sa")."')";
						mysqli_query($con,$sql);
						echo "success";
						exit;
				} else if(mysqli_num_rows($result3) > 0){
						$sql2 = "UPDATE tblattendance SET timein2='".date("h:i:sa")."' WHERE employee_id='$EID' AND date='".date("Y-m-d")."'";
						mysqli_query($con,$sql2);
						echo "success";
						exit;
				}else{
					echo "You've already timed in morning! $sql";
					exit;
				}
				
			}
			else{
					echo "Employee ID/Password is Invalid!";
					exit;
				}
			
						
		}
			//Time Out
		else if(isset($_POST['mobile']) && $_POST['mobile'] == "time_out"){
			if($count > 0){
				$sqlCheck_A = "SELECT * FROM tblattendance WHERE employee_id='$EID' AND date='".date("Y-m-d")."' AND timein1!='00:00:00' AND timeout1='00:00:00'";
				$result_A = mysqli_query($con,$sqlCheck_A);
				$sqlCheck_B = "SELECT * FROM tblattendance WHERE employee_id='$EID' AND date='".date("Y-m-d")."' AND timein2!='00:00:00' AND timeout2='00:00:00'";
				$result_B = mysqli_query($con,$sqlCheck_B);
				if(mysqli_num_rows($result_A) > 0){
					$sql3 = "UPDATE tblattendance SET timeout1='".date("h:i:s")."' WHERE employee_id='$EID' AND date='".date("Y-m-d")."'";
					mysqli_query($con,$sql3);
						echo "success";
						exit;
				}
				else if(mysqli_num_rows($result_B) > 0){
					$sql4 = "UPDATE tblattendance SET timeout2='".date("h:i:s")."' WHERE employee_id='$EID' AND date='".date("Y-m-d")."'";
					mysqli_query($con,$sql4);
					echo "success";
					exit;
				}
				else{
					echo "You've already timed out!";
					exit;
				}
			}else{
				echo "Employee ID/Password is Invalid";
				exit;
			} 
		}
?>