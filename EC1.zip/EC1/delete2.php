<?php
/*
DELETE.PHP
Deletes a specific entry from the tblusers table
*/
// connect to the database
$con=mysqli_connect("localhost","root","");
//check connection
if (mysqli_connect_errno()){
	echo "Failed to connect to MySQL: " . mysqli_connect_error();
}

mysqli_select_db($con,"ecnewdeal");

// check if the 'id' variable is set in URL, and check that it is valid
if (isset($_GET['id']) && is_numeric($_GET['id']))
{
// get id value
$id = $_GET['id'];
// delete the entry
$result = mysqli_query($con,"UPDATE tblemployees SET status='Inactive' WHERE id=$id");
// redirect back to the view page
header("Location: manageemployee.php");
}
else
// if id isn't set, or isn't valid, redirect back to view page
{
header("Location: manageemployee.php");
}



?>