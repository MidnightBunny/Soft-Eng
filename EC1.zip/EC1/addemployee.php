<!DOCTYPE HTML>
<HTML>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Add Employees</title>
	<style type="text/css">
		body {
			background-color:powderblue;
			margin:0;
			}
		a:hover{
			color:#FF0000;
		}
		table{
			border-collapse: collapse;
		}
		th{
			background-color:#7711FF;
		}
		td{
			padding:5px;
		}
		.header_links{
			background-color:Green;
			padding:10px;
			margin:auto;
		}
		.header_links a{
			color:#FFFFFF;
			font-size:18px;
			font-weight:bold;
			
			
		}
		nav ul{
			  list-style: none;
			  margin: 0 2px;
			  padding: 0;
			  display: flex;
			  justify-content: space-around;
			}
			/* Dropdown Button */
		

		/* The container <div> - needed to position the dropdown content */
		.dropdown {
			position: relative;
			display: inline-block;
		}

		/* Dropdown Content (Hidden by Default) */
		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;
		}

		/* Links inside the dropdown */
		.dropdown-content a {
			color: black;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			font-size:14px;
		}

		/* Change color of dropdown links on hover */
		.dropdown-content a:hover {background-color: #f1f1f1}

		/* Show the dropdown menu on hover */
		.dropdown:hover .dropdown-content {
			display: block;
			z-index: 10;
		}

		/* Change the background color of the dropdown button when the dropdown content is shown */
	</style>
	<script>
		function setBasePay() {
			
			if(document.getElementById("employee_type_cash").checked == true){
				document.getElementById("base_salary").value = '265.00';
				document.getElementById("sss").value = '150.00';
				document.getElementById("philhealth").value = '50.00';
			}
			else if(document.getElementById("employee_type_mer").checked == true){
				document.getElementById("base_salary").value = '250.00';
				document.getElementById("sss").value = '150.00';
				document.getElementById("philhealth").value = '50.00';
			}
			
			
	}
	</script>
	
</head>

<body>
	<nav class='header_links'>
			<ul>
				<a href="manageemployee.php" class="dropbtn">Employees</a>
				<a href="deleteuser.php" class="dropbtn">User</a>
				<a href='edituser.php' >User Settings</a>
				<a href='logout.php' >Log out</a>
			</ul>
	</nav>
	<h1 align=center>Add Employees</h1>
	<?php
	error_reporting(E_ALL ^ E_NOTICE);
	require_once("connect.php");
	$sql = "SELECT max(id) FROM tblemployees";
	$result = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($result);
	$Eid=$row[0] + 1;
	$real="ECND-100{$Eid}";
	$firstname=$_POST['first_name'];
	$lastname=$_POST['last_name'];
	$password=$_POST['password'];
	$gender=$_POST['gender'];
	$birth_date=$_POST['birth_date'];
	$civil=$_POST['civil_status'];
	$address=$_POST['address'];
	$contact_no=$_POST['contact_no'];
	$employee_type=$_POST['employee_type'];
	$bs=$_POST['base_salary'];
	$floatbs = floatval($bs);
	$sss=$_POST['sss'];
	$floatsss = floatval($sss);
	$philhealth=$_POST['philhealth'];
	$floatphilhealth = floatval($philhealth);
	
	$warningError = "<div class='alert alert-danger' role='alert'>Please fill out all fields</div>";
	if(isset($_POST['submit'])){
		if(!empty($firstname) && !empty($lastname) && !empty($password) && !empty($gender) && !empty($birth_date) && !empty($civil) && !empty($address) && !empty($contact_no) && !empty($employee_type)){
		$password=md5(md5("jed".$password."ireb"));
		$sql2 = "INSERT INTO tblemployees (employee_id,first_name,last_name,password,gender,address,contact_no,birthdate,civil_status,employee_type,base_salary,sss_contribution,philhealth) VALUES('$real','$firstname','$lastname','$password','$gender','$address','$contact_no','$birth_date','$civil','$employee_type',$floatbs,$floatsss,$floatphilhealth)";
		mysqli_query($con,$sql2);
		header('location:list.php');
		}
		else
			echo "$warningError";
	}
	?>
	<?php 
		echo "<form method=POST>
	<table align=center border=0>
		<tr>
			<div class='input-group'>
			<td colspan=2>
					<input type='text' class='form-control'  value='$real' name='employee_id' aria-describedby='basic-addon1' disabled>
			</td>
			</div>
		</tr>
		<tr>
			<div class='input-group'>
			<td colspan=2>
					<input type='password' class='form-control' placeholder='Password' name='password'aria-describedby='basic-addon1'>
			</td>
			</div>
		</tr>
		<tr>
			
			<td>
				<div class='input-group'>
					<input type='text' class='form-control' placeholder='First Name' name='first_name'aria-describedby='basic-addon1'>
				</div>
			</td>
			<td><div class='input-group'>
		<input type='text' class='form-control' placeholder='Last Name' name='last_name'aria-describedby='basic-addon1'>
		</div></td>
		</tr>
		
		<tr>
			<td>
				<div class='input-group'>
				Gender: &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				<input type='radio' value='F' name='gender'>Female
				</div>
			</td>
			<td>
				<div class='input-group'>
				<input type='radio' value='M' name='gender'>Male
				</div>
			</td>
		</tr>
		<tr>
			
			<td>
				Birthdate: 	&nbsp
			</td>
			<div class='input-group'>
			<td>
				
				<input type='date' class='form-control'  name='birth_date' aria-describedby='basic-addon1'>
				
			</td>
			</div>
			
			
		</tr>
		
		<tr>
			<td>
				<div class='input-group'>
				Civil Status:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
					<input type='radio'  value='Single' name='civil_status' >Single
				</div>
			</td>
			<td>
				<div class='input-group'>
				<input type='radio'  value='Married' name='civil_status'>Married
				</div>
			</td>
		</tr>
		<tr>
			<td colspan=2>
				<h5>Contact No</h5>
				<div class='input-group'>
					<input type='text' class='form-control' placeholder='Contact no' name='contact_no'aria-describedby='basic-addon1'>
				</div>
			</td>
		</tr>
		
		<tr>
			<td colspan=2>	
			<h5>Address</h5>
			<div class='input-group'>
		<input type='text' class='form-control' placeholder='Address' name='address' id='address' aria-describedby='basic-addon1'>
		</div></td>
		</tr>
		
		<tr>
			<td>
				<div class='input-group'>
				Civil Status:&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
				
					<input type='radio'  value='Cashier' id='employee_type_cash' name='employee_type' onchange='if(this.checked){setBasePay()}'>Cashier
					
				</div>
			</td>
			<td>
				<div class='input-group'>
				<input type='radio'  value='Merchandiser' id='employee_type_mer' name='employee_type' onchange='if(this.checked){setBasePay()}'>Merchandiser
				</div>
			</td>
		</tr>
		
		<tr>
			<div class='input-group'>
			<td colspan=2>
				<h5>Base Salary</h5>
					<input type='text' class='form-control' name='base_salary' id='base_salary' aria-describedby='basic-addon1' readonly>Per Day
			</td>
			</div>
		</tr>		
		<tr>
			<div class='input-group'>
			<td colspan=2>
				<h5>SSS Contribution</h5>
					<input type='text' class='form-control' name='sss' id='sss' aria-describedby='basic-addon1' readonly>
			</td>
			</div>
		</tr>
		
		<tr>
			<div class='input-group'>
			<td colspan=2>
				<h5>Philhealth Contribution</h5>
				
					<input type='text' class='form-control' name='philhealth' id='philhealth' aria-describedby='basic-addon1' readonly>
				
			</td>
			</div>
		</tr>
		
		<tr>
			<td colspan=2>
				<input class='btn  btn-primary btn-lg btn-block' name='submit' type='submit' value='Submit'>
			</td>
		</tr>
	</table>
	</form>";
	
	?>
	
	
</body>
</HTML>