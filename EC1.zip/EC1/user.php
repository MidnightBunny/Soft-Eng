<!DOCTYPE HTML>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<style type="text/css">
		body {
			background-color:powderblue;
			margin:0;
			}
		a:hover{
			color:#FF0000;
		}
		table{
			border-collapse: collapse;
		}
		th{
			background-color:#7711FF;
		}
		td{
			padding:5px;
		}
		.header_links{
			background-color:Green;
			padding:10px;
			margin:auto;
		}
		.header_links a{
			color:#FFFFFF;
			font-size:18px;
			font-weight:bold;
			
			
		}
		nav ul{
			  list-style: none;
			  margin: 0 2px;
			  padding: 0;
			  display: flex;
			  justify-content: space-around;
			}
			/* Dropdown Button */
		

		/* The container <div> - needed to position the dropdown content */
		.dropdown {
			position: relative;
			display: inline-block;
		}

		/* Dropdown Content (Hidden by Default) */
		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;
		}

		/* Links inside the dropdown */
		.dropdown-content a {
			color: black;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			font-size:14px;
		}

		/* Change color of dropdown links on hover */
		.dropdown-content a:hover {background-color: #f1f1f1}

		/* Show the dropdown menu on hover */
		.dropdown:hover .dropdown-content {
			display: block;
			z-index: 10;
		}

		/* Change the background color of the dropdown button when the dropdown content is shown */
	</style>
		<title>User Settings</title>
	</head>
	<body>
		<nav class='header_links'>
			<ul>
				<a href="manageemployee.php" class="dropbtn">Employees</a>
				<a href="deleteuser.php" class="dropbtn">User</a>
				<a href='edituser.php' >User Settings</a>
				<a href='logout.php' >Log out</a>
			</ul>
	</nav>
		<?php 
		error_reporting(E_ALL ^ E_NOTICE);
		include('connect.php');
		// Check connection
		if (mysqli_connect_errno())
		{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}

		if (isset($_GET['id']) && is_numeric($_GET['id'])){

		$id=$_GET['id'];
		$result = mysqli_query($con,"SELECT * FROM tblemployees WHERE id=$id");
		
		if(isset($_POST['submit'])){
			$password=$_POST['password'];
			$first_name=$_POST['first_name'];
			$last_name=$_POST['last_name'];
			$gender=$_POST['gender'];
			$birthdate=$_POST['birth_date'];
			$civil=$_POST['civil_status'];
			$contactno=$_POST['contact_no'];
			$address=$_POST['address'];
			$ET=$_POST['employee_type'];
			$password = md5(md5("jed".$password."ireb"));
			$sql="UPDATE tblemployees SET password='$password',first_name='$first_name',last_name='$last_name',gender='$gender',birthdate='$birthdate',civil_status='$civil',contact_no='$contactno',address='$address',employee_type='$ET' WHERE id=$id";
			mysqli_query($con,$sql);
			header("location:list.php");
		}
		
		echo "<form method=POST>";
		echo "<table align=center>";
		
		
		
		while($row = mysqli_fetch_array($result))
		{
		echo "<tr><td><input type='text' name='eid' value='" . $row['employee_id'] . "' readonly></td><tr>";
		echo "<tr><td><input type='password' id='txtpass' name='password' value='" . $row['password'] . "'></td><tr>";
		echo "<tr><td><input type='text'  name='first_name' value='" . $row['first_name'] . "'></td><tr>";
		echo "<tr><td><input type='text'  name='last_name' value='" . $row['last_name'] . "'></td><tr>";
		if($row['gender']=='F'){
			echo "<tr><td><input type='radio'  name='gender' value='F' checked >Female</td><tr>";
			echo "<tr><td><input type='radio'  name='gender' value='M' >Male</td><tr>";
		}
		else if($row['gender']=='M'){
			echo "<tr><td><input type='radio'  name='gender' value='F' >Female";
			echo "<input type='radio'  name='gender' value='M' checked >Male</td><tr>";
		}
		echo "<tr><td><input type='date'  name='birth_date' value='" . $row['birthdate'] . "' ></td><tr>";
	
		if($row['civil_status']=='Single'){
			echo "<tr><td><input type='radio'  name='civil_status' value='Single' checked >Single</td><tr>";
			echo "<tr><td><input type='radio'  name='civil_status' value='Married' >Married</td><tr>";
		}
		else{
			echo "<tr><td><input type='radio'  name='civil_status' value='Single' >Single";
			echo "<input type='radio'  name='civil_status' value='Married' checked >Married</td><tr>";
		}
		echo "<tr><td><input type='text' name='contact_no' value='" . $row['contact_no'] . "'></td><tr>";
		echo "<tr><td><input type='text' name='address'  value='" . $row['address'] . "'></td><tr>";
		if($row['employee_type']=='Cashier'){
			echo "<tr><td><input type='radio'  name='employee_type' value='Cashier' checked >Cashier</td><tr>";
			echo "<tr><td><input type='radio'  name='employee_type' value='Merchandiser' >Merchandiser</td><tr>";
		}
		else{
			echo "<tr><td><input type='radio'  name='employee_type' value='Cashier' >Cashier";
			echo "<input type='radio'  name='employee_type' value='Merchandiser' checked >Merchandiser</td><tr>";
		}
		}
		echo "<tr><td><input type='submit'  name='submit' value='Edit'></td><tr>";
		echo "</table>";
		echo "</form>";
		}
		mysqli_close($con);
		
?>
	</body>
</html>
