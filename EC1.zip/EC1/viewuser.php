<!DOCTYPE HTML>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<style type="text/css">
		body {
			background-color:powderblue;
			margin:0;
			}
		a:hover{
			color:#FF0000;
		}
		table{
			border-collapse: collapse;
		}
		th{
			background-color:#7711FF;
		}
		td{
			padding:5px;
		}
		.header_links{
			background-color:Green;
			padding:10px;
			margin:auto;
		}
		.header_links a{
			color:#FFFFFF;
			font-size:18px;
			font-weight:bold;
			
			
		}
		nav ul{
			  list-style: none;
			  margin: 0 2px;
			  padding: 0;
			  display: flex;
			  justify-content: space-around;
			}
			/* Dropdown Button */
		

		/* The container <div> - needed to position the dropdown content */
		.dropdown {
			position: relative;
			display: inline-block;
		}

		/* Dropdown Content (Hidden by Default) */
		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;
		}

		/* Links inside the dropdown */
		.dropdown-content a {
			color: black;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			font-size:14px;
		}

		/* Change color of dropdown links on hover */
		.dropdown-content a:hover {background-color: #f1f1f1}

		/* Show the dropdown menu on hover */
		.dropdown:hover .dropdown-content {
			display: block;
			z-index: 10;
		}

		/* Change the background color of the dropdown button when the dropdown content is shown */
	</style>
		<title>User Settings</title>
	</head>
	<body>
		<nav class='header_links'>
			<ul>
				<a href="manageemployee.php" class="dropbtn">Employees</a>
				<a href="deleteuser.php" class="dropbtn">User</a>
				<a href='edituser.php' >User Settings</a>
				<a href='logout.php' >Log out</a>
			</ul>
	</nav>
		<?php 
		error_reporting(E_ALL ^ E_NOTICE);
		include('connect.php');
		
		// Check connection
		if (mysqli_connect_errno())
		{
		echo "Failed to connect to MySQL: " . mysqli_connect_error();
		}

		if (isset($_GET['id']) && is_numeric($_GET['id'])){

		$id=$_GET['id'];
		$result = mysqli_query($con,"SELECT * FROM tblemployees WHERE id=$id");
		echo "<form method=POST>";
		echo "<table align=center>";
		
		
		
		while($row = mysqli_fetch_array($result))
		{
		echo "<tr><td><input type='text' name='eid' value='" . $row['employee_id'] . "' readonly></td><tr>";
		echo "<tr><td><input type='password' id='txtpass' name='password' value='" . $row['password'] . "' readonly></td><tr>";
		echo "<tr><td><input type='text'  name='first_name' value='" . $row['first_name'] . "' readonly></td><tr>";
		echo "<tr><td><input type='text'  name='last_name' value='" . $row['last_name'] . "' readonly></td><tr>";
		if($row['gender']=='F'){
			echo "<tr><td><input type='radio'  name='gender' value='F' checked readonly>Female</td><tr>";
			echo "<tr><td><input type='radio'  name='gender' value='M' readonly>Male</td><tr>";
		}
		else if($row['gender']=='M'){
			echo "<tr><td><input type='radio'  name='gender' value='F' readonly>Female";
			echo "<input type='radio'  name='gender' value='M' checked readonly>Male</td><tr>";
		}
		echo "<tr><td><input type='date'  name='birth_date' value='" . $row['birthdate'] . "' readonly></td><tr>";
	
		if($row['civil_status']=='Single'){
			echo "<tr><td><input type='radio'  name='civil_status' value='Single' checked readonly>Single</td><tr>";
			echo "<tr><td><input type='radio'  name='civil_status' value='Married' readonly>Married</td><tr>";
		}
		else{
			echo "<tr><td><input type='radio'  name='civil_status' value='Single' readonly>Single";
			echo "<input type='radio'  name='civil_status' value='Married' checked readonly>Married</td><tr>";
		}
		echo "<tr><td><input type='text' name='contact_no' value='" . $row['contact_no'] . "' readonly></td><tr>";
		echo "<tr><td><input type='text' name='address'  value='" . $row['address'] . "' readonly></td><tr>";
		if($row['employee_type']=='Cashier'){
			echo "<tr><td><input type='radio'  name='employee_type' value='Cashier' checked readonly>Cashier</td><tr>";
			echo "<tr><td><input type='radio'  name='employee_type' value='Merchandiser' readonly>Merchandiser</td><tr>";
		}
		else{
			echo "<tr><td><input type='radio'  name='employee_type' value='Cashier' readonly>Cashier";
			echo "<input type='radio'  name='employee_type' value='Merchandiser' checked readonly>Merchandiser</td><tr>";
		}
		}
		echo "</table>";
		echo "</form>";
		}
		mysqli_close($con);
		
?>
	</body>
</html>
