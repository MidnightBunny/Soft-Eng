<!DOCTYPE HTML>
<HTML>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	

	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Manage Employees</title>
	<style type="text/css">
		body {
			background-color:powderblue;
			margin:0;
			}
		a:hover{
			color:#FF0000;
		}
		table{
			border-collapse: collapse;
			margin-left:auto;
			margin-right:auto;
			margin-top:10px;
		}
		th{
			background-color:#7711FF;
		}
		td{
			padding:5px;
		}
		.header_links{
			background-color:Green;
			padding:10px;
			margin:auto;
		}
		.header_links a{
			color:#FFFFFF;
			font-size:18px;
			font-weight:bold;
			
			
		}
		nav ul{
			  list-style: none;
			  margin: 0 2px;
			  padding: 0;
			  display: flex;
			  justify-content: space-around;
			}
			/* Dropdown Button */
		

		/* The container <div> - needed to position the dropdown content */
		.dropdown {
			position: relative;
			display: inline-block;
		}

		/* Dropdown Content (Hidden by Default) */
		.dropdown-content {
			display: none;
			position: absolute;
			background-color: #f9f9f9;
			min-width: 160px;
			box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
			z-index: 1;
		}

		/* Links inside the dropdown */
		.dropdown-content a {
			color: black;
			padding: 12px 16px;
			text-decoration: none;
			display: block;
			font-size:14px;
		}

		/* Change color of dropdown links on hover */
		.dropdown-content a:hover {background-color: #f1f1f1}

		/* Show the dropdown menu on hover */
		.dropdown:hover .dropdown-content {
			display: block;
			z-index: 10;
		}

		/* Change the background color of the dropdown button when the dropdown content is shown */
		
	</style>
</head>
<body>
	<nav class='header_links'>
			<ul>
				<a href="manageemployee.php" class="dropbtn">Employees</a>
				<a href="deleteuser.php" class="dropbtn">User</a>
				<a href='edituser.php' >User Settings</a>
				<a href='logout.php' >Log out</a>
			</ul>
	</nav>
	<?php
	error_reporting(E_ALL ^ E_NOTICE);
	require_once("connect.php");
	$sql=mysqli_query($con,"SELECT * FROM tblemployees");
	echo "<a href='addemployee.php'>Add Employee Account</a>";
	echo 
	"
	<table border=1>
		<tr>
			<th>Employee ID</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Employee Type</th>
			<th>Status</th>
			<th></th>
			<th></th>
			<th></th>
		</tr>
		<tr></tr>";
	while($row = mysqli_fetch_array($sql))
	{
		echo "<tr><td>". $row['employee_id'] ."</td>";
		echo "<td>". $row['first_name'] ."</td>";
		echo "<td>". $row['last_name'] ."</td>";
		echo "<td>". $row['employee_type'] ."</td>";
		echo "<td>". $row['status'] ."</td>";
		echo "<td><a href='viewuser.php?id=" . $row['id'] . "'>View</a>";
		if($row['status']=='Active'){
		echo "<td><a href='user.php?id=" . $row['id'] . "'>Edit</a>";
		echo "<td><a href='delete2.php?id=" . $row['id'] . "'>Delete</a>";}
		else
			echo "<td></td><td></td>";
		echo "</tr>";
	}
	echo "</table>";
	mysqli_close($con);
	
?>
</body>