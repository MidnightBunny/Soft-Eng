<?php
	if (isset($_GET['id']) && is_numeric($_GET['id'])){
		include('connect.php');
		$id=$_GET['id'];
		$result = mysqli_query($con,"SELECT * FROM tblemployees WHERE id=$id");
		
		
		$row = mysqli_fetch_array($result);
		$work=mysqli_query($con,"SELECT * FROM tblattendance WHERE employee_id='".$row['employee_id']."'");
		$workdays = mysqli_num_rows($work);
		echo "$workdays";
		$bs=$row['base_salary'] * $workdays;
		$sss=$row['sss_contribution'];
		$ph=$row['philhealth'];
		$total=$bs - ($sss + $ph);
		echo "<table border=1>";
		echo "<tr><td></td><td></td><td>No: ".$row['employee_id']."</td></tr>";
		echo "<tr><td></td>";
		echo "<td></td>";
		echo "<td>Date:".date("m-d-Y")."</td></tr>";
		echo "<tr><td>Paid to: ".$row['first_name']." ".$row['last_name']."</td></tr>";
		echo "<tr><td>Address: ".$row['address']."</td></tr>";
		echo "<tr><td colspan=3 align=center>Particulars</td></tr>";
		echo "<tr><td>Salary for m-d-y to m-d-y:</td><td>".$bs."</td></tr>";
		echo "<tr><td colspan=3 align=center>Deductions</td></tr>";
		echo "<tr><td>SSS Contribution:</td><td>".$sss."</td></tr>";
		echo "<tr><td>Philhealth:</td><td>".$ph."</td></tr>";
		echo "<tr><td>Total:</td><td>".$total."</td></tr>";
		echo "</table>";
	}
?>